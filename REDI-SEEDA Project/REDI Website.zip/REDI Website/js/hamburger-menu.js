// This is the code for the hamburger menu that's on every page excluding the user pages
