// This array was made for the EIA office page and either will be changed manually to display the offices or changed via some other way


const data = [{
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'email@example.com',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },

    // Just copy and paste this block of code
    {
        officeName: 'Office Name',
        faxNumber: '(xxx)-xxx-xxxx',
        email: 'email@example.com',
        website: 'website.ca',
        addressl1: 'address line 1',
        addressl2: 'address line 2',
        location: 'EX: Calgary, AB',
        postalCode: 'xxx xxx',
        publicationsLink1: 'weblink.ca',
        // publicationsLink2 can be left blank
        publicationsLink2: '',
    },
    // Paste it right here--

    // When you want to add more eia offices to the data table all you have to do
    // is copy from the open angle bracket to the closed one with the comma and than 
    // paste is beneath this last code block and just edit the text in apostrophies


]

// Instructions
// Take the data above and display it as tiles on the page
let html = ""
const fillCards = document.querySelector('.cards-wrapper')

for (info of data) {
    html = html + `
        <div class="cards">
            <div class="heading-container">
                <h4>${info.officeName}</h4>
                <h3>${info.location}</h3>
            </div>
            <div>
            <ul class="information-list">
                <li>${info.faxNumber}</li>
                <li>${info.email}</li>
                <li><a href=""> ${info.website}</li></a>
                <li>${info.addressl1}</li>
                <li>${info.addressl2}</li>
                <li>${info.postalCode}</li>
                <li><a href="">${info.publicationsLink1}</li></a>
            </ul>

            </div>
        </div>`

}
// After the

fillCards.innerHTML += html